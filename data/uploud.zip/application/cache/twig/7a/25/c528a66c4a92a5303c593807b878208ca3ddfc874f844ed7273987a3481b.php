<?php

/* layout-footer.html */
class __TwigTemplate_7a25c528a66c4a92a5303c593807b878208ca3ddfc874f844ed7273987a3481b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<script type=\"text/javascript\">
var site_url = \"";
        // line 2
        echo twig_escape_filter($this->env, site_url(), "html", null, true);
        echo "\";
var base_url = \"";
        // line 3
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "\";
</script>
<script src=\"";
        // line 5
        echo twig_escape_filter($this->env, base_url("assets/comp/jquery/jquery.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
<script src=\"";
        // line 6
        echo twig_escape_filter($this->env, base_url("assets/comp/jquery/jquery-ui-1.10.1.custom.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
<script data-pace-options='{ \"ajax\": false }' src=\"";
        // line 7
        echo twig_escape_filter($this->env, base_url("assets/comp/pace/pace.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
<script src=\"";
        // line 8
        echo twig_escape_filter($this->env, base_url("assets/comp/offline/offline.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
<script src=\"";
        // line 9
        echo twig_escape_filter($this->env, base_url("assets/comp/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>";
        // line 10
        echo (isset($context["comp_js"]) ? $context["comp_js"] : null);
        echo "
<script src=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["base_url_theme"]) ? $context["base_url_theme"] : null), "html", null, true);
        echo "scripts/script.js\" type=\"text/javascript\"></script>
";
    }

    public function getTemplateName()
    {
        return "layout-footer.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 9,  26 => 3,  22 => 2,  37 => 7,  29 => 5,  25 => 4,  43 => 8,  27 => 4,  19 => 1,  197 => 96,  192 => 77,  187 => 6,  181 => 4,  174 => 97,  172 => 96,  170 => 95,  162 => 90,  159 => 89,  146 => 78,  141 => 74,  139 => 73,  132 => 67,  111 => 49,  107 => 48,  104 => 47,  99 => 45,  97 => 44,  92 => 41,  90 => 40,  85 => 37,  83 => 36,  77 => 32,  71 => 29,  69 => 28,  67 => 27,  46 => 9,  35 => 6,  33 => 6,  23 => 3,  339 => 190,  328 => 180,  320 => 177,  317 => 176,  313 => 175,  304 => 167,  293 => 163,  289 => 161,  285 => 160,  278 => 154,  267 => 150,  263 => 148,  259 => 147,  252 => 141,  245 => 136,  240 => 132,  238 => 131,  236 => 130,  234 => 129,  222 => 117,  214 => 114,  211 => 113,  207 => 112,  200 => 106,  193 => 101,  188 => 97,  186 => 96,  184 => 95,  182 => 94,  171 => 83,  163 => 80,  160 => 79,  156 => 78,  144 => 77,  140 => 67,  134 => 64,  130 => 66,  124 => 60,  120 => 59,  114 => 56,  110 => 55,  106 => 53,  95 => 44,  84 => 36,  73 => 28,  66 => 23,  64 => 22,  62 => 21,  58 => 20,  54 => 11,  52 => 14,  50 => 10,  45 => 11,  39 => 7,  31 => 5,  28 => 4,);
    }
}
