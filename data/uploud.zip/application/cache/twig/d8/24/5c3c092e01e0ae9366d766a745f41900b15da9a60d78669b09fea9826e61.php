<?php

/* layout-header.html */
class __TwigTemplate_d8245c3c092e01e0ae9366d766a745f41900b15da9a60d78669b09fea9826e61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<link type=\"text/css\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, base_url("assets/comp/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
<link type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, base_url("assets/comp/bootstrap/css/bootstrap-responsive.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
<link type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["base_url_theme"]) ? $context["base_url_theme"] : null), "html", null, true);
        echo "css/theme.css\" rel=\"stylesheet\">
<link type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, base_url("assets/comp/font-awesome/css/font-awesome.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
<link type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, base_url("assets/comp/pace/flash.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
<link type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, base_url("assets/comp/offline/offline-theme-chrome.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">";
        // line 9
        echo (isset($context["comp_css"]) ? $context["comp_css"] : null);
        echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["favicon_url"]) ? $context["favicon_url"] : null), "html", null, true);
        echo "\">
";
    }

    public function getTemplateName()
    {
        return "layout-header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 8,  27 => 4,  19 => 1,  197 => 96,  192 => 77,  187 => 6,  181 => 4,  174 => 97,  172 => 96,  170 => 95,  162 => 90,  159 => 89,  146 => 78,  141 => 74,  139 => 73,  132 => 67,  111 => 49,  107 => 48,  104 => 47,  99 => 45,  97 => 44,  92 => 41,  90 => 40,  85 => 37,  83 => 36,  77 => 32,  71 => 29,  69 => 28,  67 => 27,  46 => 9,  35 => 6,  33 => 6,  23 => 3,  339 => 190,  328 => 180,  320 => 177,  317 => 176,  313 => 175,  304 => 167,  293 => 163,  289 => 161,  285 => 160,  278 => 154,  267 => 150,  263 => 148,  259 => 147,  252 => 141,  245 => 136,  240 => 132,  238 => 131,  236 => 130,  234 => 129,  222 => 117,  214 => 114,  211 => 113,  207 => 112,  200 => 106,  193 => 101,  188 => 97,  186 => 96,  184 => 95,  182 => 94,  171 => 83,  163 => 80,  160 => 79,  156 => 78,  144 => 77,  140 => 67,  134 => 64,  130 => 66,  124 => 60,  120 => 59,  114 => 56,  110 => 55,  106 => 53,  95 => 44,  84 => 36,  73 => 28,  66 => 23,  64 => 22,  62 => 21,  58 => 20,  54 => 15,  52 => 14,  50 => 10,  45 => 11,  39 => 7,  31 => 5,  28 => 4,);
    }
}
