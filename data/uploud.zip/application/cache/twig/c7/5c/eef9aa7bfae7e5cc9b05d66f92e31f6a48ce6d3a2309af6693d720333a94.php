<?php

/* login.html */
class __TwigTemplate_c75ceef9aa7bfae7e5cc9b05d66f92e31f6a48ce6d3a2309af6693d720333a94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">

    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>


    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>


    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, base_url("assets/themes/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">


    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, base_url("assets/themes/css/nifty.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">


    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, base_url("assets/themes/css/demo/nifty-demo-icons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">


    <!--=================================================-->



    <!--Pace - Page Load Progress Par [OPTIONAL]-->
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, base_url("assets/themes/plugins/pace/pace.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <script src=\"";
        // line 36
        echo twig_escape_filter($this->env, base_url("assets/themes/plugins/pace/pace.min.js"), "html", null, true);
        echo "\"></script>


        
    <!--Demo [ DEMONSTRATION ]-->
    <link href=\"";
        // line 41
        echo twig_escape_filter($this->env, base_url("assets/themes/css/demo/nifty-demo.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

        
</head>
<body>
    <div id=\"container\" class=\"cls-container\">
        
        <!-- BACKGROUND IMAGE -->
        <!--===================================================-->
        <div id=\"bg-overlay\"></div>
        
        
        <!-- LOGIN FORM -->
        <!--===================================================-->
        <div class=\"cls-content\">
            <div class=\"cls-content-sm panel\">
                <div class=\"panel-body\">
                    <div class=\"mar-ver pad-btm\">
                        <h1 class=\"h3\">Login E-learning</h1>
                        <p>Sign In to your account</p>
                    </div>";
        // line 62
        echo form_open("login", array("autocomplete" => "off", "class" => "form-vertical"));
        // line 63
        echo get_flashdata("login");
        echo "
                        <div class=\"form-group\">
                            <input type=\"text\" class=\"form-control\" name=\"email\" placeholder=\"Username (Email)\" value=\"";
        // line 65
        echo twig_escape_filter($this->env, set_value("email"), "html", null, true);
        echo "\" autofocus>";
        // line 66
        echo form_error("email");
        echo "
                        </div>
                        <div class=\"form-group\">
                            <input type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\">
                        </div>
                        <button class=\"btn btn-primary btn-lg btn-block\" type=\"submit\">Sign In</button>
                    </form>
                </div>
        
                <div class=\"pad-all\">
                    <a href=\"";
        // line 76
        echo twig_escape_filter($this->env, site_url("login/lupa_password"), "html", null, true);
        echo "\" class=\"btn-link mar-rgt\">Lupa password ?</a>";
        // line 77
        if (((get_pengaturan("registrasi-siswa", "value") == 1) || (get_pengaturan("registrasi-pengajar", "value") == 1))) {
            // line 78
            echo "                    <a href=\"";
            echo twig_escape_filter($this->env, site_url("login/register"), "html", null, true);
            echo "\" class=\"btn-link mar-lft\">Buat akun</a>";
        }
        // line 80
        echo "        
                </div>
            </div>
        </div>
        <!--===================================================-->
        
        
        
        
        
    </div>
    <!--===================================================-->
    <!-- END OF CONTAINER -->


        
    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--jQuery [ REQUIRED ]-->
    <script src=\"";
        // line 100
        echo twig_escape_filter($this->env, base_url("assets/themes/js/jquery.min.js"), "html", null, true);
        echo "\"></script>


    <!--BootstrapJS [ RECOMMENDED ]-->
    <script src=\"";
        // line 104
        echo twig_escape_filter($this->env, base_url("assets/themes/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>


    <!--NiftyJS [ RECOMMENDED ]-->
    <script src=\"";
        // line 108
        echo twig_escape_filter($this->env, base_url("assets/themes/js/nifty.min.js"), "html", null, true);
        echo "\"></script>




    <!--=================================================-->
    
    <!--Background Image [ DEMONSTRATION ]-->
    <script src=\"";
        // line 116
        echo twig_escape_filter($this->env, base_url("assets/themes/js/demo/bg-images.js"), "html", null, true);
        echo "\"></script>

</body>
</html>
";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 8,  183 => 116,  172 => 108,  165 => 104,  158 => 100,  136 => 80,  131 => 78,  129 => 77,  126 => 76,  113 => 66,  110 => 65,  105 => 63,  103 => 62,  80 => 41,  72 => 36,  68 => 35,  57 => 27,  50 => 23,  43 => 19,  29 => 8,  20 => 1,);
    }
}
