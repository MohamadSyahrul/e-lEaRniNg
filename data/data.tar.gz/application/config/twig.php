<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['template_dir'] = APPPATH.'views';
$config['cache_dir']    = APPPATH.'cache/twig';