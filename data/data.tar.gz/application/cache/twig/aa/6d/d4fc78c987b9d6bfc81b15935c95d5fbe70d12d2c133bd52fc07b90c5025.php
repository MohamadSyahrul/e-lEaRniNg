<?php

/* analisis-soal-print.html */
class __TwigTemplate_aa6dd4fc78c987b9d6bfc81b15935c95d5fbe70d12d2c133bd52fc07b90c5025 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-print.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-print.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Analisis Soal - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<table class=\"table table-condensed\">
    <thead>
        <tr>
            <th width=\"7%\">No.</th>
            <th>Pertanyaan dan Pilihan</th>
            <th width=\"18%\">Hasil</th>
        </tr>
    </thead>
    <tbody>
        ";
        // line 17
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pertanyaan"]) ? $context["pertanyaan"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 18
            echo "        <tr id=\"pertanyaan-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
            <td>
                <b>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
            echo ".</b>
            </td>
            <td>
                <div class=\"pertanyaan\">
                    ";
            // line 24
            echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
            echo "
                </div>

                <div id=\"pilihan-";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                    <table class=\"table table-condensed table-striped\">
                        <tbody>
                            ";
            // line 30
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
            foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                    // line 31
                    echo "                            <tr>
                                <td style=\"width:15px;\"><b>";
                    // line 32
                    echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan")), "html", null, true);
                    echo "</b></td>
                                <td>
                                    ";
                    // line 34
                    echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                    echo "

                                    <ul class=\"unstyled inline\" style=\"margin-bottom: 0px;margin-left: -5px;\">
                                        ";
                    // line 37
                    if (($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) {
                        // line 38
                        echo "                                            <li><small class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci Jawaban</small></li>
                                        ";
                    }
                    // line 40
                    echo "                                    </ul>
                                </td>
                            </tr>
                            ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "                        </tbody>
                    </table>
                </div>

            </td>
            <td>
                ";
            // line 50
            if (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "sulit")) {
                // line 51
                echo "                    ";
                $context["text_class"] = "label-warning";
                // line 52
                echo "                ";
            } elseif (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "sedang")) {
                // line 53
                echo "                    ";
                $context["text_class"] = "label-info";
                // line 54
                echo "                ";
            } elseif (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "mudah")) {
                // line 55
                echo "                    ";
                $context["text_class"] = "label-success";
                // line 56
                echo "                ";
            } else {
                // line 57
                echo "                    ";
                $context["text_class"] = "";
                // line 58
                echo "                ";
            }
            // line 59
            echo "
                <b class=\"label ";
            // line 60
            echo twig_escape_filter($this->env, (isset($context["text_class"]) ? $context["text_class"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array")), "html", null, true);
            echo "</b>

                <br><br>
                <table class=\"table table-bordered\">
                    <tbody>
                        <tr>
                            <td>Jawab benar</td>
                            <td>";
            // line 67
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "benar", array(), "array"), "html", null, true);
            echo "</td>
                        </tr>
                        <tr>
                            <td>Penjawab</td>
                            <td>";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "dari", array(), "array"), "html", null, true);
            echo "</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>

        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "    </tbody>
</table>
";
    }

    public function getTemplateName()
    {
        return "analisis-soal-print.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  208 => 79,  186 => 71,  179 => 67,  167 => 60,  164 => 59,  161 => 58,  158 => 57,  155 => 56,  152 => 55,  149 => 54,  146 => 53,  143 => 52,  140 => 51,  138 => 50,  130 => 44,  120 => 40,  116 => 38,  114 => 37,  108 => 34,  103 => 32,  100 => 31,  95 => 30,  89 => 27,  83 => 24,  76 => 20,  70 => 18,  53 => 17,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
