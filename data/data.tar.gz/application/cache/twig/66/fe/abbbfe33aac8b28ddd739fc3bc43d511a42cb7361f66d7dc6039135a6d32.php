<?php

/* kd-form-list-kd-mapel.html */
class __TwigTemplate_66feabbbfe33aac8b28ddd739fc3bc43d511a42cb7361f66d7dc6039135a6d32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<table class=\"table table-striped\">";
        // line 3
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kd_mapel"]) ? $context["kd_mapel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 4
            echo "<tr>
    <td>
        <label>
            <input type=\"checkbox\" name=\"kd_mapel_id[]\" value=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\" style=\"margin-top:-5px;\"";
            // line 8
            if ((!twig_test_empty((isset($context["default_checked"]) ? $context["default_checked"] : null)))) {
                // line 9
                if (in_array($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), (isset($context["default_checked"]) ? $context["default_checked"] : null))) {
                    // line 10
                    echo "                    checked=\"\"";
                }
            } else {
                // line 13
                echo "                checked=\"\"";
            }
            // line 15
            echo "            > <span id=\"label-kd-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "</span>
            <div id=\"edit-";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\" class=\"collapse\">
                <table class=\"table table-condensed table-striped\">
                    <tr>
                        <td>
                            <input type=\"text\" class=\"input-small span10\" id=\"edit-value-";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\" placeholder=\"Nama KD\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "\">
                        </td>
                        <td><button class=\"btn btn-primary update-kd\" type=\"button\" data-id=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\">Update</button></td>
                    </tr>
                </table>
            </div>
        </label>
    </td>
    <td width=\"20%\">
        <div class=\"btn-group\">
            <button type=\"button\" class=\"btn btn-xs btn-primary\" data-toggle=\"collapse\" data-target=\"#edit-";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\">Edit</button>
            <button type=\"button\" class=\"btn btn-xs btn-default delete-kd\" data-id=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\">Hapus</button>
        </div>
    </td>
</tr>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "</table>
";
    }

    public function getTemplateName()
    {
        return "kd-form-list-kd-mapel.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 36,  81 => 31,  77 => 30,  66 => 22,  59 => 20,  52 => 16,  45 => 15,  42 => 13,  38 => 10,  36 => 9,  34 => 8,  31 => 7,  26 => 4,  22 => 3,  19 => 1,);
    }
}
