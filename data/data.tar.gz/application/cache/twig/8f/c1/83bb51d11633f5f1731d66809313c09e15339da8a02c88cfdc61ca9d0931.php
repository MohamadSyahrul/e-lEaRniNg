<?php

/* kd-layout-hasil.html */
class __TwigTemplate_8fc183bb51d11633f5f1731d66809313c09e15339da8a02c88cfdc61ca9d0931 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 5
        $this->env->loadTemplate("layout-header.html")->display($context);
        // line 6
        echo "        <style type=\"text/css\">
            body {
                font-size: 10px;
            }
        </style>
        ";
        // line 11
        $this->displayBlock('css', $context, $blocks);
        // line 12
        echo "    </head>

    <body>
        <br>
        <div class=\"kop-print\">
            <img src=\"";
        // line 17
        echo twig_escape_filter($this->env, get_logo_config(), "html", null, true);
        echo "\">
            <div class=\"kop-nama\">";
        // line 18
        echo twig_escape_filter($this->env, get_pengaturan("nama-sekolah", "value"), "html", null, true);
        echo "</div>
            <div class=\"kop-info\">Alamat : ";
        // line 19
        echo twig_escape_filter($this->env, get_pengaturan("alamat", "value"), "html", null, true);
        echo ", Telepon : ";
        echo twig_escape_filter($this->env, get_pengaturan("telp", "value"), "html", null, true);
        echo "</div>
        </div>
        <hr class=\"kop-print-hr\">
        <br>
        ";
        // line 23
        $this->displayBlock('content', $context, $blocks);
        // line 24
        echo "
    </body>
</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
    }

    // line 11
    public function block_css($context, array $blocks = array())
    {
    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "kd-layout-hasil.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 23,  81 => 11,  75 => 4,  68 => 24,  66 => 23,  57 => 19,  49 => 17,  40 => 11,  33 => 6,  31 => 5,  27 => 4,  22 => 1,  178 => 60,  172 => 58,  170 => 57,  165 => 54,  150 => 52,  143 => 50,  139 => 48,  133 => 46,  131 => 45,  128 => 44,  124 => 43,  120 => 42,  116 => 41,  113 => 40,  96 => 39,  91 => 36,  82 => 34,  78 => 33,  72 => 30,  60 => 21,  53 => 18,  42 => 12,  39 => 7,  32 => 4,  29 => 3,);
    }
}
