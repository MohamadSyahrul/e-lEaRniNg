<?php

/* tk-list-tugas.html */
class __TwigTemplate_c9d6be1cf4a5cb248aa777264663568c94178ce18d8f934553ec0a0f4760c0bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Tugas Kelompok -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>Tugas Kelompok</h3>
    </div>
    <div class=\"module-body\">";
        // line 13
        echo get_flashdata("tugas");
        echo "

        <div class=\"bs-callout bs-callout-info\">";
        // line 16
        if ((is_siswa() == false)) {
            // line 17
            echo "            <div class=\"btn-group pull-right\" style=\"margin-top:-5px;\">";
            // line 18
            echo anchor("plugins/tugas_kelompok/add", "Tambah Tugas", array("class" => "btn btn-primary"));
            echo "
            </div>";
        }
        // line 21
        echo "            <b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#form-filter\"><i class=\"icon-search\" style=\"line-height: 0px;\"></i> PARAMETER PENCARIAN</a></b>

            <div id=\"form-filter\" class=\"collapse\" style=\"margin-top: 5px;\">";
        // line 24
        echo form_open("plugins/tugas_kelompok/index");
        echo "
                    <table class=\"table table-condensed\">
                        <tr>
                            <th  style=\"border-top: none;\">Mapel</th>
                            <td  style=\"border-top: none;\">
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mapel"]) ? $context["mapel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 31
            echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"mapel_id[]\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
            echo "\"";
            echo twig_escape_filter($this->env, set_checkbox("mapel_id[]", $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id"))) && in_array($this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "mapel_id")))) ? (true) : (""))), "html", null, true);
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nama"), "html", null, true);
            echo "
                                        </label>
                                    </li>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                                </ul>
                            </td>
                        </tr>";
        // line 40
        if ((is_siswa() == false)) {
            // line 41
            echo "                        <tr>
                            <th>Kelas</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">";
            // line 45
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["kelas"]) ? $context["kelas"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
                // line 46
                echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"kelas_id[]\" value=\"";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
                echo "\"";
                echo twig_escape_filter($this->env, set_checkbox("kelas_id[]", $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id"))) && in_array($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "kelas_id")))) ? (true) : (""))), "html", null, true);
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
                echo "
                                        </label>
                                    </li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "                                </ul>
                            </td>
                        </tr>";
        }
        // line 56
        echo "                        <tr>
                            <th width=\"15%\">Judul</th>
                            <td>
                                <input type=\"text\" name=\"judul\" class=\"span4\" value=\"";
        // line 59
        echo twig_escape_filter($this->env, set_value("judul", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "judul")), "html", null, true);
        echo "\">
                            </td>
                        </tr>";
        // line 62
        if ((is_pengajar() == false)) {
            // line 63
            echo "                        <tr>
                            <th>Pembuat</th>
                            <td>
                                <input type=\"text\" name=\"pembuat\" class=\"span4\" value=\"";
            // line 66
            echo twig_escape_filter($this->env, set_value("pembuat", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "pembuat")), "html", null, true);
            echo "\">
                            </td>
                        </tr>";
        }
        // line 70
        echo "                        <tr>
                            <th>Status</th>
                            <td>
                                <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">";
        // line 74
        if ((is_siswa() == false)) {
            // line 75
            echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"status[]\" value=\"1\"";
            // line 77
            echo twig_escape_filter($this->env, set_checkbox("status[]", "1", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status"))) && in_array("1", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status")))) ? (true) : (""))), "html", null, true);
            echo "> Draft
                                        </label>
                                    </li>";
        }
        // line 81
        echo "                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"status[]\" value=\"2\"";
        // line 83
        echo twig_escape_filter($this->env, set_checkbox("status[]", "2", ((((!twig_test_empty($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status"))) && in_array("2", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status")))) ? (true) : (""))), "html", null, true);
        echo "> Terbit
                                        </label>
                                    </li>
                                    <li>
                                        <label class=\"checkbox inline\">
                                            <input type=\"checkbox\" name=\"status[]\" value=\"3\"";
        // line 88
        echo twig_escape_filter($this->env, set_checkbox("status[]", "3", (((($this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status") != "") && in_array("3", $this->getAttribute((isset($context["filter"]) ? $context["filter"] : null), "status")))) ? (true) : (""))), "html", null, true);
        echo "> Tutup
                                        </label>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <button type=\"submit\" class=\"btn btn-primary\">Filter</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>

        </div>
        <br>

        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th width=\"7%\">ID</th>
                    <th>Judul</th>
                    <th>Matapelajaran</th>";
        // line 113
        if ((is_siswa() == false)) {
            // line 114
            echo "                    <th>Kelas</th>";
        }
        // line 116
        echo "                    <th>Status</th>
                    <th>Pembuat</th>";
        // line 118
        if ((is_siswa() == true)) {
            // line 119
            echo "                    <th></th>";
        }
        // line 121
        echo "                </tr>
            </thead>
            <tbody>";
        // line 124
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tugas"]) ? $context["tugas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
            // line 125
            echo "                <tr class=\"";
            echo ((($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "status") == 2)) ? ("success") : (""));
            echo "\">
                    <td>";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "id"), "html", null, true);
            echo "</td>
                    <td>";
            // line 128
            if (is_siswa()) {
                // line 129
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "judul"), "html", null, true);
            } else {
                // line 131
                echo "                            <b><a href=\"";
                echo twig_escape_filter($this->env, site_url(("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "id"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "judul"), "html", null, true);
                echo "</a></b>";
            }
            // line 133
            echo "                    </td>
                    <td>";
            // line 134
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "mapel"), "nama"), "html", null, true);
            echo "</td>";
            // line 135
            if ((is_siswa() == false)) {
                // line 136
                echo "                    <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "kelas"), "nama"), "html", null, true);
                echo "</td>";
            }
            // line 138
            echo "                    <td>";
            // line 139
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "label_status")), "html", null, true);
            echo "
                    </td>
                    <td>
                        <a href=\"";
            // line 142
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "pengajar"), "link_profil"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "pengajar"), "nama"), "html", null, true);
            echo "</a>
                    </td>";
            // line 144
            if ((is_siswa() == true)) {
                // line 145
                echo "                    <td>
                        <div class=\"btn-group\">";
                // line 147
                if (($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "status") == 2)) {
                    // line 148
                    echo "                                <a href=\"";
                    echo twig_escape_filter($this->env, site_url(("plugins/tugas_kelompok/kerjakan/" . $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "id"))), "html", null, true);
                    echo "\" class=\"btn btn-primary btn-xs\"><i class=\"icon icon-play\"></i> Kerjakan</a>";
                } elseif (($this->getAttribute((isset($context["d"]) ? $context["d"] : null), "status") == 3)) {
                    // line 150
                    echo "                                <a href=\"";
                    echo twig_escape_filter($this->env, site_url(("plugins/tugas_kelompok/nilai/" . $this->getAttribute((isset($context["d"]) ? $context["d"] : null), "id"))), "html", null, true);
                    echo "\" class=\"btn btn-primary btn-xs\"><i class=\"icon-info-sign\"></i> Lihat Nilai</a>";
                }
                // line 152
                echo "                        </div>
                    </td>";
            }
            // line 155
            echo "                </tr>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 157
        echo "            </tbody>
        </table>
        <br>";
        // line 160
        echo (isset($context["pagination"]) ? $context["pagination"] : null);
        echo "

    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "tk-list-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  309 => 160,  305 => 157,  299 => 155,  295 => 152,  290 => 150,  285 => 148,  283 => 147,  280 => 145,  278 => 144,  272 => 142,  266 => 139,  264 => 138,  259 => 136,  257 => 135,  254 => 134,  251 => 133,  244 => 131,  241 => 129,  239 => 128,  235 => 126,  230 => 125,  226 => 124,  222 => 121,  219 => 119,  217 => 118,  214 => 116,  211 => 114,  209 => 113,  182 => 88,  174 => 83,  170 => 81,  164 => 77,  160 => 75,  158 => 74,  153 => 70,  147 => 66,  142 => 63,  140 => 62,  135 => 59,  130 => 56,  125 => 52,  112 => 48,  108 => 46,  104 => 45,  99 => 41,  97 => 40,  93 => 37,  80 => 33,  76 => 31,  72 => 30,  64 => 24,  60 => 21,  55 => 18,  53 => 17,  51 => 16,  46 => 13,  40 => 8,  37 => 7,  32 => 4,  29 => 3,);
    }
}
