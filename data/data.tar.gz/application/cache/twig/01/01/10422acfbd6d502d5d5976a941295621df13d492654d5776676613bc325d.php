<?php

/* kd-no-soal.html */
class __TwigTemplate_010110422acfbd6d502d5d5976a941295621df13d492654d5776676613bc325d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "KD Nomor Soal - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("plugins/pencapaian_kd", "Analisis Pencapaian Kompetensi Dasar");
        echo " / KD Nomor Soal</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("kd");
        echo "

        <table class=\"table table-bordered datatable table-striped\">
            <thead>
                <tr>
                    <th width=\"10%\">Analisis ID</th>
                    <th>Tugas & Kopetensi Dasar</th>
                    <th width=\"15%\">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <tr>
                <td>#";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id"), "html", null, true);
        echo "</td>
                <td>
                    ID : ";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "id"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "judul"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "mapel"), "nama"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "nama_kelas"), "html", null, true);
        echo "<br>
                    <hr style=\"margin-top:5px; margin-bottom: 5px;\">
                    KD : ";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "kd_mapel_nama"), "html", null, true);
        echo "
                    <br>Nilai Minimal Lulus : ";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "nilai_lulus"), "html", null, true);
        echo "
                </td>
                <td>
                    <div class=\"btn-group\">
                        <a class=\"btn btn-xs btn-default\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, site_url(((("plugins/pencapaian_kd/edit/" . $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id")) . "/") . enurl_redirect(current_url()))), "html", null, true);
        echo "\"><i class=\"icon icon-edit\"></i> Edit</a>
                        <a class=\"btn btn-xs btn-success\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, site_url(("plugins/pencapaian_kd/hasil_data/" . $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id"))), "html", null, true);
        echo "\"><i class=\"icon icon-download\"></i> Hasil Data</a>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
        <br>

        <table class=\"table\">
            <thead>
                <tr>
                    <th width=\"5%\">No</th>
                    <th>Pertanyaan dan Pilihan</th>
                    <th>Pilih Kompetensi Dasar</th>
                </tr>
            </thead>
            <tbody>
                ";
        // line 52
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pertanyaan"]) ? $context["pertanyaan"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 53
            echo "                <tr id=\"pertanyaan-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                    <td><b>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
            echo ".</b></td>
                    <td>
                        <div class=\"pertanyaan\">
                            ";
            // line 57
            echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
            echo "
                        </div>

                        <div id=\"pilihan-";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                            <table class=\"table table-condensed table-striped\">
                                <tbody>
                                    ";
            // line 63
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
            foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                    // line 64
                    echo "                                    <tr>
                                        <td width=\"5%\">";
                    // line 65
                    echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan")), "html", null, true);
                    echo "</td>
                                        <td>
                                            ";
                    // line 67
                    echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                    echo "
                                        </td>
                                    </tr>
                                    ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 71
            echo "                                </tbody>
                            </table>
                        </div>

                    </td>
                    <td>
                        <select class=\"select_kd\" data-pertanyaan-id=\"";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                            <option>--pilih--</option>
                            ";
            // line 79
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "kd_tugas_kd"));
            foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
                // line 80
                echo "                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
                echo "\" ";
                echo ((((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "no_soal_arr"), "pertanyaan_id"))) && in_array($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), $this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "no_soal_arr"), "pertanyaan_id")))) ? ("selected") : (""));
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "kd_mapel"), "nama"), "html", null, true);
                echo "</option>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "                        </select>
                        <div id=\"result-";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\"></div>
                    </td>
                </tr>

                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "            </tbody>
        </table>

    </div>
</div>
";
    }

    // line 95
    public function block_js($context, array $blocks = array())
    {
        // line 96
        echo "<script type=\"text/javascript\">
    \$(document).on('change', '.select_kd', function() {
        var kd_tugas_kd_id = \$(this).val();
        var pertanyaan_id  = \$(this).data('pertanyaan-id');

        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/pencapaian_kd/ajax/set_kd_no_soal',
            data: {'id': kd_tugas_kd_id, 'pertanyaan_id': pertanyaan_id},
            success: function (data) {
                if (data == 1) {
                    \$(\"#result-\" + pertanyaan_id).html(\"<div class='alert alert-success'><i class='icon icon-ok'></i> Data berhasil disimpan</div>\");
                } else if (data == 0) {
                    \$(\"#result-\" + pertanyaan_id).html(\"Data gagal disimpan\");
                }

                setTimeout(function() {
                    \$(\"#result-\" + pertanyaan_id).html(\"\");
                }, 2000);
            },
            async: false,
        });
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "kd-no-soal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  247 => 96,  244 => 95,  235 => 88,  216 => 83,  213 => 82,  200 => 80,  196 => 79,  191 => 77,  183 => 71,  172 => 67,  167 => 65,  164 => 64,  159 => 63,  153 => 60,  147 => 57,  141 => 54,  136 => 53,  119 => 52,  99 => 35,  95 => 34,  88 => 30,  84 => 29,  73 => 27,  68 => 25,  53 => 13,  47 => 10,  43 => 8,  40 => 7,  33 => 4,  30 => 3,);
    }
}
