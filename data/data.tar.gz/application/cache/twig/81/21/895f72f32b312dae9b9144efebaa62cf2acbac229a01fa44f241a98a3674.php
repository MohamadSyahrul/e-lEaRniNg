<?php

/* kd-tambah-tugas.html */
class __TwigTemplate_8121895f72f32b312dae9b9144efebaa62cf2acbac229a01fa44f241a98a3674 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Tambah Analisis -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("plugins/pencapaian_kd", "Analisis Pencapaian Kompetensi Dasar");
        echo " / Tambah Analisis</h3>
    </div>
    <div class=\"module-body\">";
        // line 13
        echo form_open("plugins/pencapaian_kd/add", array("class" => "form-horizontal row-fluid"));
        echo "
            <div class=\"control-group\">
                <label class=\"control-label\">Tugas Pilihan Ganda <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <select name=\"tugas_id\" id=\"tugas_id\">
                        <option value=\"\">--pilih--</option>";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tugas_ganda"]) ? $context["tugas_ganda"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 20
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"), "html", null, true);
            echo " -";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "judul"), "html", null, true);
            echo "</option>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "                    </select>
                    <br>";
        // line 23
        echo form_error("tugas_id");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Nilai Minimal Lulus</label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"nilai_lulus\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, set_value("nilai_lulus", "0.00"), "html", null, true);
        echo "\" style=\"width: 50px;\">
                    <br>";
        // line 30
        echo form_error("nilai_lulus");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\" id=\"view_response\"></div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\">";
        // line 38
        echo form_error("kd_mapel_id[]");
        echo "
                    <div class=\"btn-group\">
                        <button type=\"submit\" class=\"btn btn-primary\">Simpan</button>
                        <a href=\"";
        // line 41
        echo twig_escape_filter($this->env, site_url("plugins/pencapaian_kd"), "html", null, true);
        echo "\" class=\"btn\">Batal</a>
                    </div>
                </div>
            </div>";
        // line 45
        echo form_close();
        echo "

    </div>
</div>";
    }

    // line 51
    public function block_js($context, array $blocks = array())
    {
        // line 52
        echo "<script type=\"text/javascript\">
    \$(\"#tugas_id\").on('change', function() {
        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/pencapaian_kd/ajax/on_select_tugas_id',
            data: {tugas_id: \$(this).val()},
            success: function (data) {
                \$(\"#view_response\").html(data);
            },
            async: false,
        });

        list_form_kd_mapel(\$(this).val());
    });

    \$(document).on('click', '#btn_new_kd', function() {
        var tugas_id    = \$(\"#tugas_id\").val();
        var new_nama_kd = \$(\"#new_nama_kd\").val();
        if (new_nama_kd == '') {
            alert(\"Nama KD dibutuhkan\");
            return (false);
        }

        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/pencapaian_kd/ajax/add_kd_mapel',
            data: {'tugas_id': tugas_id, 'nama': new_nama_kd},
            async: false,
        });

        list_form_kd_mapel(tugas_id);

        \$(\"#new_nama_kd\").val(\"\");
    });

    \$(document).on('click', '.update-kd', function() {
        var kd_id = \$(this).data(\"id\");
        var new_nama_kd = \$(\"#edit-value-\" + kd_id).val();

        \$(\"#label-kd-\" + kd_id).html(new_nama_kd);

        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/pencapaian_kd/ajax/edit_kd_mapel',
            data: {'id': kd_id, 'nama': new_nama_kd},
            async: false,
        });

        \$(\"#edit-\" + kd_id).collapse('hide');
    });

    \$(document).on('click', '.delete-kd', function() {
        var conf = confirm(\"Anda yakin ingin menghapus?\");
        if (conf) {
            var kd_id = \$(this).data(\"id\");

            \$.ajax({
                type: \"POST\",
                url: site_url + '/plugins/pencapaian_kd/ajax/delete_kd_mapel',
                data: {'id': kd_id},
                async: false,
            });

            \$(this).closest(\"tr\").remove();
        }

        return (false);
    });

    function list_form_kd_mapel(tugas_id)
    {
        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/pencapaian_kd/ajax/form_list_kd_mapel',
            data: {'tugas_id': tugas_id},
            success: function (data) {
                \$(\"#view_form_list_kd_mapel\").html(data);
            }
        });
    }
</script>";
    }

    public function getTemplateName()
    {
        return "kd-tambah-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 52,  120 => 51,  112 => 45,  106 => 41,  100 => 38,  90 => 30,  86 => 29,  77 => 23,  74 => 22,  62 => 20,  58 => 19,  50 => 13,  45 => 10,  41 => 8,  38 => 7,  33 => 4,  30 => 3,);
    }
}
