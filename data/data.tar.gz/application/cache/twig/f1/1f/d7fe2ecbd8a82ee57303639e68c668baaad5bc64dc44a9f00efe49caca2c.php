<?php

/* copy-bank-soal.html */
class __TwigTemplate_f11fd7fe2ecbd8a82ee57303639e68c668baaad5bc64dc44a9f00efe49caca2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-iframe.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-iframe.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h4>Bank Soal</h4>
<table class=\"table table-striped\">
    <tbody>
        <tr>
            <td>
                <form method=\"post\" action=\"";
        // line 9
        echo twig_escape_filter($this->env, site_url(("plugins/bank_soal/search/" . (isset($context["tugas_id_iframe_copy"]) ? $context["tugas_id_iframe_copy"] : null))), "html", null, true);
        echo "\">
                    <select name=\"mapel_id\" class=\"form-control\">
                        <option value=\"all\">Semua Matapelajaran</option>";
        // line 12
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mapel"]) ? $context["mapel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 13
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
            echo "\"";
            echo ((((isset($context["mapel_id"]) ? $context["mapel_id"] : null) == $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"))) ? ("selected") : (""));
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nama"), "html", null, true);
            echo "</option>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "                    </select>
                    <input type=\"text\" name=\"q\" placeholder=\"cari soal...\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["keyword"]) ? $context["keyword"] : null), "html", null, true);
        echo "\">
                    <button type=\"submit\" class=\"btn btn-primary\" style=\"margin-top:-10px;\"><i class=\"icon-search\"></i></button>
                </form>
            </td>
        </tr>
    </tbody>
</table>
<div class=\"tampil-tertandai\"></div>

<br>";
        // line 26
        echo get_flashdata("bank");
        echo "

<table class=\"table\">
    <thead>
        <tr>
            <th width=\"5%\">ID</th>
            <th>Pertanyaan</th>
            <th width=\"15%\">Aksi</th>
        </tr>
    </thead>
    <tbody>";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pertanyaan"]) ? $context["pertanyaan"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 38
            echo "        <tr>
            <td><b>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "</b></td>
            <td>";
            // line 41
            echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
            // line 43
            if ((!twig_test_empty($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci")))) {
                // line 44
                echo "                <table class=\"table table-striped table-condensed\" style=\"margin-bottom: 10px;margin-top:10px;\">
                    <tr>
                        <td width=\"5%\"><b>A</b></td>
                        <td>";
                // line 48
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan_a");
                // line 49
                if (($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci") == "a")) {
                    // line 50
                    echo "                            <div style=\"display:block;\"><span class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci jawaban</span></div>";
                }
                // line 52
                echo "                        </td>
                    </tr>
                    <tr>
                        <td><b>B</b></td>
                        <td>";
                // line 57
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan_b");
                // line 58
                if (($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci") == "b")) {
                    // line 59
                    echo "                            <div style=\"display:block;\"><span class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci jawaban</span></div>";
                }
                // line 61
                echo "                        </td>
                    </tr>
                    <tr>
                        <td><b>C</b></td>
                        <td>";
                // line 66
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan_c");
                // line 67
                if (($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci") == "c")) {
                    // line 68
                    echo "                            <div style=\"display:block;\"><span class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci jawaban</span></div>";
                }
                // line 70
                echo "                        </td>
                    </tr>
                    <tr>
                        <td><b>D</b></td>
                        <td>";
                // line 75
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan_d");
                // line 76
                if (($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci") == "d")) {
                    // line 77
                    echo "                            <div style=\"display:block;\"><span class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci jawaban</span></div>";
                }
                // line 79
                echo "                        </td>
                    </tr>
                    <tr>
                        <td><b>E</b></td>
                        <td>";
                // line 84
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan_e");
                // line 85
                if (($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "kunci") == "e")) {
                    // line 86
                    echo "                            <div style=\"display:block;\"><span class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci jawaban</span></div>";
                }
                // line 88
                echo "                        </td>
                    </tr>
                </table>";
            }
            // line 92
            echo "                <div style=\"display:block;\"><b>Pembuat: </b>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "user"), "nama"), "html", null, true);
            echo ", <b>Matapelajaran: </b>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "mapel"), "nama"), "html", null, true);
            echo "</div>
            </td>
            <td>
                <label style=\"font-weight: bold;\">
                    <input type=\"checkbox\" class=\"btn-tandai\"";
            // line 96
            echo ((in_array($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), (isset($context["session_tandai"]) ? $context["session_tandai"] : null))) ? ("checked") : (""));
            echo " data-pid=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\" style=\"margin-top: -2px;\"> <i class=\"icon icon-ok\"></i> Tandai soal
                </label>
                <div id=\"tampil-loading-";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\"></div>
            </td>
        </tr>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 102
        echo "    </tbody>
</table>
<br>
<div class=\"tampil-tertandai\"></div>
<br>";
        // line 107
        echo (isset($context["pagination"]) ? $context["pagination"] : null);
    }

    // line 110
    public function block_js($context, array $blocks = array())
    {
        // line 111
        echo "<script type=\"text/javascript\">
var tugas_id = \"";
        // line 112
        echo twig_escape_filter($this->env, (isset($context["tugas_id_iframe_copy"]) ? $context["tugas_id_iframe_copy"] : null), "html", null, true);
        echo "\";

function tampil_tertandai() {
    \$(\".tampil-tertandai\").html('<img src=\"' + base_url + 'assets/images/loading.gif\" style=\"width:30px;\">');
    \$.ajax({
        url: site_url + '/plugins/bank_soal/ajax/get_tandai',
        type: \"GET\",
        data: {'tugas_id':tugas_id},
        success: function(data) {
            if (data == \"0\") {
                \$(\".tampil-tertandai\").html(\"\");
            } else {
                \$(\".tampil-tertandai\").html(data);
            }
        }
    });
}

tampil_tertandai();

\$(document).on('click', '.btn-tandai', function() {
    var pid = \$(this).data('pid');
    if (\$(this).prop('checked') == true) {
        var act = 'add';
    } else {
        var act = 'remove';
    }

    \$(\"#tampil-loading-\" + pid).html('<img src=\"' + base_url + 'assets/images/loading.gif\" style=\"width:30px;\">');

    \$.ajax({
        url: site_url + '/plugins/bank_soal/ajax/tandai/',
        type: \"POST\",
        data: {'act': act, 'tugas_id':tugas_id, 'pid':pid},
        success: function(data) {
            \$(\"#tampil-loading-\" + pid).html(\"\");
            tampil_tertandai();
        }
    });
});
</script>";
    }

    public function getTemplateName()
    {
        return "copy-bank-soal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 112,  211 => 111,  208 => 110,  204 => 107,  198 => 102,  189 => 98,  182 => 96,  172 => 92,  167 => 88,  164 => 86,  162 => 85,  160 => 84,  154 => 79,  151 => 77,  149 => 76,  147 => 75,  141 => 70,  138 => 68,  136 => 67,  134 => 66,  128 => 61,  125 => 59,  123 => 58,  121 => 57,  115 => 52,  112 => 50,  110 => 49,  108 => 48,  103 => 44,  101 => 43,  99 => 41,  95 => 39,  92 => 38,  88 => 37,  75 => 26,  63 => 16,  60 => 15,  48 => 13,  44 => 12,  39 => 9,  32 => 4,  29 => 3,);
    }
}
