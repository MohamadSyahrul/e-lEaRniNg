<?php

/* tk-kelompok.html */
class __TwigTemplate_7f344e6dbc890dac5934ce0f94e0cfbfc8b26ee6ed7d8d002a8145693b69b874 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "List Kelompok -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("plugins/tugas_kelompok", "Tugas Kelompok");
        echo " / List Kelompok</h3>
    </div>
    <div class=\"module-body\">
        <div class=\"bs-callout bs-callout-info\">
            <div class=\"btn-group pull-right\" style=\"margin-top:-5px;\">";
        // line 15
        echo anchor(((("plugins/tugas_kelompok/edit/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon icon-edit\"></i> Edit Tugas", array("class" => "btn btn-default"));
        // line 16
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "status") != 2)) {
            // line 17
            echo anchor(((("plugins/tugas_kelompok/terbitkan/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-ok\"></i> Terbitkan", array("class" => "btn btn-success btn-small"));
        } else {
            // line 19
            echo anchor(((("plugins/tugas_kelompok/tutup/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-minus\"></i> Tutup", array("class" => "btn btn-danger btn-small"));
        }
        // line 21
        echo "            </div>";
        // line 23
        $this->env->loadTemplate("tk-info-tugas.html")->display($context);
        // line 24
        echo "
        </div>
        <br>";
        // line 27
        echo get_flashdata("tugas");
        echo "
        <div class=\"btn-group\">
            <a class=\"btn btn-primary\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, site_url((("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/add")), "html", null, true);
        echo "\">Tambah Kelompok</a>
        </div>

        <br><br>
        <table class=\"table table-striped table-bordered datatable\">
            <thead>
                <tr>
                    <th width=\"6%\">#ID</th>
                    <th>Kelompok</th>
                    <th width=\"35%\">Anggota</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>";
        // line 43
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) ? $context["results"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 44
            echo "                <tr>
                    <td>#";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "</td>
                    <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "
                        <hr style=\"margin-top: 5px; margin-bottom: 5px;\">";
            // line 49
            echo $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "intruksi");
            echo "
                    </td>
                    <td>
                        <ul>";
            // line 53
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "anggota"));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 54
                echo "                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["a"]) ? $context["a"] : null), "siswa"), "link_profil"), "html", null, true);
                echo "\" target=\"_blank\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["a"]) ? $context["a"] : null), "siswa"), "nis"), "html", null, true);
                echo " -";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["a"]) ? $context["a"] : null), "siswa"), "nama"), "html", null, true);
                echo "</a></li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 56
            echo "                        </ul>
                    </td>
                    <td>
                        <div class=\"btn-group\">
                            <a href=\"";
            // line 60
            echo twig_escape_filter($this->env, site_url(((("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/edit/") . $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"))), "html", null, true);
            echo "\" class=\"btn btn-xs btn-default\"><i class=\"icon icon-edit\"></i> Edit</a>";
            // line 62
            if (($this->getAttribute((isset($context["k"]) ? $context["k"] : null), "jml_kerjaan") > 0)) {
                // line 63
                echo "                            <a href=\"";
                echo twig_escape_filter($this->env, site_url(((("plugins/tugas_kelompok/koreksi/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"))), "html", null, true);
                echo "\" target=\"_blank\" class=\"btn btn-xs btn-primary\"><i class=\"icon icon-eye-open\"></i> Koreksi</a>";
            }
            // line 65
            echo "                        </div>
                    </td>
                </tr>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "            </tbody>
        </table>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "tk-kelompok.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 69,  143 => 65,  138 => 63,  136 => 62,  133 => 60,  127 => 56,  115 => 54,  111 => 53,  105 => 49,  101 => 47,  97 => 45,  94 => 44,  90 => 43,  74 => 29,  69 => 27,  65 => 24,  63 => 23,  61 => 21,  58 => 19,  55 => 17,  53 => 16,  51 => 15,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 3,);
    }
}
