<?php

/* pengaturan-bank-soal.html */
class __TwigTemplate_ada0211a8c452dd238b001d0d0887e7cdae5c4899df6c431353b08f67b44b03a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Pengaturan Bank Soal -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("tugas", "Tugas");
        echo " /";
        echo anchor("plugins/bank_soal", "Bank Soal");
        echo " / Pengaturan</h3>
    </div>
    <div class=\"module-body\">";
        // line 13
        echo get_flashdata("pengaturan");
        // line 15
        if (is_demo_app()) {
            // line 16
            echo get_alert("warning", get_demo_msg());
        }
        // line 19
        echo form_open_multipart("plugins/bank_soal/pengaturan", array("class" => "form-horizontal row-fluid"));
        echo "
            <div class=\"control-group\">
                <label class=\"control-label\">Tampil soal diadmin</label>
                <div class=\"controls\">
                    <label class=\"radio inline\">
                        <input type=\"radio\" name=\"tampil_diadmin\" value=\"1\"";
        // line 24
        echo twig_escape_filter($this->env, set_radio("tampil_diadmin", "1", ((((isset($context["tampil_diadmin"]) ? $context["tampil_diadmin"] : null) == "1")) ? (true) : (""))), "html", null, true);
        echo "> Semua soal siapapun pembuatnya
                    </label>
                    <br>
                    <label class=\"radio inline\">
                        <input type=\"radio\" name=\"tampil_diadmin\" value=\"2\"";
        // line 28
        echo twig_escape_filter($this->env, set_radio("tampil_diadmin", "2", ((((isset($context["tampil_diadmin"]) ? $context["tampil_diadmin"] : null) == "2")) ? (true) : (""))), "html", null, true);
        echo "> Hanya soal yang dibuat admin ybs
                    </label>
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Tampil soal dipengajar</label>
                <div class=\"controls\">
                    <label class=\"radio inline\">
                        <input type=\"radio\" name=\"tampil_dipengajar\" value=\"1\"";
        // line 36
        echo twig_escape_filter($this->env, set_radio("tampil_dipengajar", "1", ((((isset($context["tampil_dipengajar"]) ? $context["tampil_dipengajar"] : null) == "1")) ? (true) : (""))), "html", null, true);
        echo "> Semua soal siapapun pembuatnya
                    </label>
                    <br>
                    <label class=\"radio inline\">
                        <input type=\"radio\" name=\"tampil_dipengajar\" value=\"2\"";
        // line 40
        echo twig_escape_filter($this->env, set_radio("tampil_dipengajar", "2", ((((isset($context["tampil_dipengajar"]) ? $context["tampil_dipengajar"] : null) == "2")) ? (true) : (""))), "html", null, true);
        echo "> Hanya soal yang dibuat pengajar ybs
                    </label>
                </div>
            </div>";
        // line 45
        if ((is_demo_app() == false)) {
            // line 46
            echo "            <div class=\"control-group\">
                <div class=\"controls\">
                    <button type=\"submit\" class=\"btn btn-primary\">Update</button>
                </div>
            </div>";
        }
        // line 52
        echo form_close();
        echo "

    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "pengaturan-bank-soal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 52,  99 => 46,  97 => 45,  91 => 40,  84 => 36,  73 => 28,  66 => 24,  58 => 19,  55 => 16,  53 => 15,  51 => 13,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 3,);
    }
}
