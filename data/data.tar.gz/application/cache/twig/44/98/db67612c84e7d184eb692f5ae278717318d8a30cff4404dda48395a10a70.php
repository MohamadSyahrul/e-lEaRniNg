<?php

/* analisis-soal.html */
class __TwigTemplate_4498db67612c84e7d184eb692f5ae278717318d8a30cff4404dda48395a10a70 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Analisis Soal - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("tugas", "Tugas");
        echo " / ";
        echo anchor(("tugas/nilai/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")), "Lihat Nilai");
        echo " / Analisis Soal</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("tugas");
        echo "

        <div class=\"bs-callout bs-callout-info\">
            <div class=\"btn-group pull-right\" style=\"margin-top:-5px;\">
                ";
        // line 17
        echo anchor(((("plugins/custom_tugas/edit/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon icon-edit\"></i> Edit Tugas", array("class" => "btn btn-default"));
        echo "
                ";
        // line 18
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 0)) {
            // line 19
            echo "                    ";
            echo anchor(((("tugas/terbitkan/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-ok\"></i> Terbitkan", array("class" => "btn btn-success btn-small"));
            echo "
                ";
        } elseif (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "aktif") == 1)) {
            // line 21
            echo "                    ";
            echo anchor(((("tugas/tutup/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/") . enurl_redirect(current_url())), "<i class=\"icon-minus\"></i> Tutup", array("class" => "btn btn-danger btn-small"));
            echo "
                ";
        }
        // line 23
        echo "            </div>

            ";
        // line 25
        $this->env->loadTemplate("info-tugas.html")->display($context);
        // line 26
        echo "
        </div>
        <br>
        <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, site_url((("plugins/analisis_soal/index/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "?mode=print")), "html", null, true);
        echo "\" class=\"btn btn-primary\" target=\"_blank\">Print Analisis</a>
        <br><br>

        <table class=\"table table-condensed datatable\">
            <thead>
                <tr>
                    <th width=\"7%\">No.</th>
                    <th>Pertanyaan dan Pilihan</th>
                    <th width=\"18%\">Hasil</th>
                </tr>
            </thead>
            <tbody>
                ";
        // line 41
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pertanyaan"]) ? $context["pertanyaan"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 42
            echo "                <tr id=\"pertanyaan-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                    <td>
                        <b>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
            echo ".</b>
                    </td>
                    <td>
                        <div class=\"pertanyaan\">
                            ";
            // line 48
            echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
            echo "
                        </div>

                        <div id=\"pilihan-";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\">
                            <table class=\"table table-condensed table-striped\">
                                <tbody>
                                    ";
            // line 54
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
            foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                    // line 55
                    echo "                                    <tr>
                                        <td style=\"width:15px;\"><b>";
                    // line 56
                    echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan")), "html", null, true);
                    echo "</b></td>
                                        <td>
                                            ";
                    // line 58
                    echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                    echo "

                                            <ul class=\"unstyled inline\" style=\"margin-bottom: 0px;margin-left: -5px;\">
                                                ";
                    // line 61
                    if (($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) {
                        // line 62
                        echo "                                                    <li><small class=\"text-warning\"><i class=\"icon icon-star\"></i> Kunci Jawaban</small></li>
                                                ";
                    }
                    // line 64
                    echo "                                            </ul>
                                        </td>
                                    </tr>
                                    ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 68
            echo "                                </tbody>
                            </table>
                        </div>

                    </td>
                    <td>
                        ";
            // line 74
            if (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "sulit")) {
                // line 75
                echo "                            ";
                $context["text_class"] = "label-warning";
                // line 76
                echo "                        ";
            } elseif (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "sedang")) {
                // line 77
                echo "                            ";
                $context["text_class"] = "label-info";
                // line 78
                echo "                        ";
            } elseif (($this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array") == "mudah")) {
                // line 79
                echo "                            ";
                $context["text_class"] = "label-success";
                // line 80
                echo "                        ";
            } else {
                // line 81
                echo "                            ";
                $context["text_class"] = "";
                // line 82
                echo "                        ";
            }
            // line 83
            echo "
                        <b class=\"label ";
            // line 84
            echo twig_escape_filter($this->env, (isset($context["text_class"]) ? $context["text_class"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "kategori", array(), "array")), "html", null, true);
            echo "</b>

                        <br><br>
                        <table class=\"table table-bordered\">
                            <tbody>
                                <tr>
                                    <td>Jawab benar</td>
                                    <td>";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "benar", array(), "array"), "html", null, true);
            echo "</td>
                                </tr>
                                <tr>
                                    <td>Penjawab</td>
                                    <td>";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["analisis"]) ? $context["analisis"] : null), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array"), "dari", array(), "array"), "html", null, true);
            echo "</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>

                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "            </tbody>
        </table>

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "analisis-soal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 103,  238 => 95,  231 => 91,  219 => 84,  216 => 83,  213 => 82,  210 => 81,  207 => 80,  204 => 79,  201 => 78,  198 => 77,  195 => 76,  192 => 75,  190 => 74,  182 => 68,  172 => 64,  168 => 62,  166 => 61,  160 => 58,  155 => 56,  152 => 55,  147 => 54,  141 => 51,  135 => 48,  128 => 44,  122 => 42,  105 => 41,  90 => 29,  85 => 26,  83 => 25,  79 => 23,  73 => 21,  67 => 19,  65 => 18,  61 => 17,  54 => 13,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
