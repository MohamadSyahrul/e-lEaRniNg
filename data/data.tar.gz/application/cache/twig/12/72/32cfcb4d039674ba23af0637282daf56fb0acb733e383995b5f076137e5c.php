<?php

/* info-tugas.html */
class __TwigTemplate_127232cfcb4d039674ba23af0637282daf56fb0acb733e383995b5f076137e5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#detail-tugas\"><i class=\"icon-info-sign\" style=\"line-height: 0px;\"></i>";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul")), "html", null, true);
        echo "</a></b>

<div id=\"detail-tugas\" class=\"collapse\" style=\"margin-top: 5px;\">
    <table class=\"table\">
        <tr>
            <th style=\"border-top: none;\" width=\"30%\">Tipe</th>
            <td style=\"border-top: none;\">";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_label"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Judul</th>
            <td>";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Matapelajaran</th>
            <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "mapel"), "nama"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Kelas</th>
            <td>
                <ul class=\"unstyled inline\" style=\"margin-left: -5px;margin-bottom: 0px;\">";
        // line 21
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "tugas_kelas"));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 22
            echo "                    <li>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "</li>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "                </ul>
            </td>
        </tr>
        <tr>
            <th>Info</th>
            <td>";
        // line 29
        echo $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "info");
        echo "</td>
        </tr>";
        // line 31
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") != 1)) {
            // line 32
            $context["pengaturan_tugas"] = plugin_helper("custom_tugas", "get_pengaturan_tugas", array("tugas_id" => $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")));
            // line 33
            echo "        <tr>
            <th>Maksimal jumlah soal</th>
            <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "max_jml_soal"), "html", null, true);
            echo "</td>
        </tr>
        <tr>
            <th>Model urutan soal</th>
            <td>";
            // line 39
            echo ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "model_urutan_soal") == 1)) ? ("Acak") : ("Berurutan"));
            echo "</td>
        </tr>";
            // line 41
            if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 3)) {
                // line 42
                echo "        <tr>
            <th>Model urutan pilihan</th>
            <td>";
                // line 44
                echo ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "model_urutan_pilihan") == 1)) ? ("Acak") : ("Berurutan"));
                echo "</td>
        </tr>";
            }
            // line 47
            echo "        <tr>
            <th>Tampil soal perhalaman</th>
            <td>";
            // line 49
            echo twig_escape_filter($this->env, ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_soal_perhalaman") == 0)) ? ("Semua") : ($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_soal_perhalaman"))), "html", null, true);
            echo "</td>
        </tr>
        <tr>
            <th>Durasi</th>
            <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "durasi"), "html", null, true);
            echo " Menit</td>
        </tr>";
        }
        // line 56
        echo "        <tr>
            <th>Tampil nilai ke siswa</th>
            <td>";
        // line 59
        if (twig_test_empty($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_nilai_kesiswa"))) {
            // line 60
            $context["option_tampil_nilai_kesiswa"] = 1;
        } else {
            // line 62
            $context["option_tampil_nilai_kesiswa"] = $this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_nilai_kesiswa");
        }
        // line 65
        echo twig_escape_filter($this->env, plugin_helper("custom_tugas", "ct_option_tampil_nilai_kesiswa", array(0 => (isset($context["option_tampil_nilai_kesiswa"]) ? $context["option_tampil_nilai_kesiswa"] : null))), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <th>Otomatis terbit pada</th>
            <td>";
        // line 70
        echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "terbitkan_pada")), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Otomatis tutup pada</th>
            <td>";
        // line 74
        echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tutup_pada")), "html", null, true);
        echo "</td>
        </tr>
    </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "info-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 74,  140 => 70,  132 => 65,  126 => 60,  115 => 53,  108 => 49,  104 => 47,  99 => 44,  95 => 42,  93 => 41,  89 => 39,  82 => 35,  70 => 29,  55 => 22,  51 => 21,  43 => 15,  36 => 11,  29 => 7,  19 => 1,  247 => 121,  243 => 120,  240 => 119,  232 => 113,  228 => 110,  220 => 105,  215 => 101,  205 => 97,  202 => 95,  200 => 94,  196 => 92,  191 => 91,  186 => 90,  181 => 87,  178 => 86,  176 => 85,  172 => 82,  168 => 79,  164 => 78,  157 => 74,  152 => 73,  148 => 72,  142 => 68,  133 => 62,  129 => 62,  124 => 59,  120 => 56,  116 => 54,  112 => 53,  105 => 49,  101 => 48,  97 => 47,  88 => 40,  86 => 39,  84 => 37,  81 => 35,  78 => 33,  76 => 32,  74 => 31,  68 => 27,  63 => 24,  59 => 22,  56 => 21,  42 => 8,  39 => 7,  34 => 4,  31 => 3,);
    }
}
