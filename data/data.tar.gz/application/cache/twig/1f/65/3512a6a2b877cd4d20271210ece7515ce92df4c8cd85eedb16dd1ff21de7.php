<?php

/* kd-hasil-data-analisis.html */
class __TwigTemplate_1f653512a6a2b877cd4d20271210ece7515ce92df4c8cd85eedb16dd1ff21de7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("kd-layout-hasil.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "kd-layout-hasil.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Hasil Data - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<center>
    <h5>
        ANALISIS PENCAPAIAN KOMPETENSI DASAR
    </h5>
</center>

<table>
    <tr>
        <td><b>Matapelajaran</b></td>
        <td>: ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "mapel"), "nama"), "html", null, true);
        echo "</td>
    </tr>
    <tr>
        <td><b>Judul Soal</b></td>
        <td>: ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "judul"), "html", null, true);
        echo "</td>
    </tr>
</table>

<table class=\"table table-bordered table-hover table-condensed\">
    <thead>
        <tr bgcolor=\"#f5f5f5\">
            <th rowspan=\"2\">Kompetensi Dasar</th>
            <th rowspan=\"2\">No.Soal</th>
            <th colspan=\"";
        // line 30
        echo twig_escape_filter($this->env, count((isset($context["kelas_nilai"]) ? $context["kelas_nilai"] : null)), "html", null, true);
        echo "\"><center>Jumlah soal yg dijawab benar oleh siswa / kelas</center></th>
        </tr>
        <tr bgcolor=\"#f5f5f5\">
            ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kelas_nilai"]) ? $context["kelas_nilai"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 34
            echo "            <th>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "        </tr>
    </thead>
    <tbody>
        ";
        // line 39
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["list_pertanyaan_id"]) ? $context["list_pertanyaan_id"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 40
            echo "        <tr>
            <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["list_kd_pertanyaan_id"]) ? $context["list_kd_pertanyaan_id"] : null), (isset($context["p"]) ? $context["p"] : null), array(), "array"), "html", null, true);
            echo "</td>
            <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
            echo "</td>
            ";
            // line 43
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["kelas_nilai"]) ? $context["kelas_nilai"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
                // line 44
                echo "                <td>
                    ";
                // line 45
                if ((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["list_perkelas"]) ? $context["list_perkelas"] : null), $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), array(), "array"), (isset($context["p"]) ? $context["p"] : null), array(), "array")))) {
                    // line 46
                    echo "                        ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["list_perkelas"]) ? $context["list_perkelas"] : null), $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), array(), "array"), (isset($context["p"]) ? $context["p"] : null), array(), "array"), "html", null, true);
                    echo "
                    ";
                } else {
                    // line 48
                    echo "                        0
                    ";
                }
                // line 50
                echo "                </td>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "        </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "    </tbody>
</table>
<br>
";
        // line 57
        if (twig_test_empty((isset($context["mode"]) ? $context["mode"] : null))) {
            // line 58
            echo "<a href=\"";
            echo twig_escape_filter($this->env, site_url(((("plugins/pencapaian_kd/hasil_data/" . $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id")) . "/analisis_kd") . "?mode=excel")), "html", null, true);
            echo "\" class=\"btn btn-primary\">Cetak Excel</a>
";
        }
        // line 60
        echo "
";
    }

    public function getTemplateName()
    {
        return "kd-hasil-data-analisis.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 60,  172 => 58,  170 => 57,  165 => 54,  150 => 52,  143 => 50,  139 => 48,  133 => 46,  131 => 45,  128 => 44,  124 => 43,  120 => 42,  116 => 41,  113 => 40,  96 => 39,  91 => 36,  82 => 34,  78 => 33,  72 => 30,  60 => 21,  53 => 17,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
