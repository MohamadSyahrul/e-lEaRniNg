<?php

/* kd-list-kd-mapel.html */
class __TwigTemplate_921024351b05e496dbe75142ebca171dd7e02f4e91f2724630c77090f3131337 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<a class=\"as-link pull-right\" data-toggle=\"collapse\" data-target=\"#form-add\">Tambah KD</a>
<h4>Pilih KD Mapel <b>\"";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "mapel"), "nama"), "html", null, true);
        echo "\"</b></h4>

<div id=\"form-add\" class=\"";
        // line 5
        echo (((!twig_test_empty((isset($context["kd_mapel"]) ? $context["kd_mapel"] : null)))) ? ("collapse") : (""));
        echo "\">
    <table class=\"table table-condensed table-striped\">
        <tr>
            <td>Tambah KD</td>
            <td>
                <input type=\"text\" id=\"new_nama_kd\" class=\"input-small span10\" placeholder=\"Nama KD\">
            </td>
            <td><button class=\"btn btn-primary\" id=\"btn_new_kd\" type=\"button\">Simpan</button></td>
        </tr>
    </table>
    <br>
</div>

<div id=\"view_form_list_kd_mapel\"></div>
";
    }

    public function getTemplateName()
    {
        return "kd-list-kd-mapel.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 5,  23 => 3,  19 => 1,);
    }
}
