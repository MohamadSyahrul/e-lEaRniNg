<?php

/* tk-info-tugas.html */
class __TwigTemplate_14693c9d740d492975342b10992493514b78b3c677e10e43dc8b78445089444a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#detail-tugas\"><i class=\"icon-info-sign\" style=\"line-height: 0px;\"></i>";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul")), "html", null, true);
        echo "</a></b>

<div id=\"detail-tugas\" class=\"collapse\" style=\"margin-top: 5px;\">
    <table class=\"table\">
        <tr>
            <th width=\"20%\">Judul</th>
            <td>";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Matapelajaran</th>
            <td>";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "mapel"), "nama"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Kelas</th>
            <td>";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "kelas"), "nama"), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <th>Status</th>
            <td>";
        // line 22
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "label_status")), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <th>Pembuat</th>
            <td>
                <a href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "pengajar"), "link_profil"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "pengajar"), "nama"), "html", null, true);
        echo "</a>
            </td>
        </tr>
    </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "tk-info-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 28,  43 => 16,  36 => 11,  19 => 1,  151 => 69,  143 => 65,  138 => 63,  136 => 62,  133 => 60,  127 => 56,  115 => 54,  111 => 53,  105 => 49,  101 => 47,  97 => 45,  94 => 44,  90 => 43,  74 => 29,  69 => 27,  65 => 24,  63 => 23,  61 => 21,  58 => 19,  55 => 17,  53 => 16,  51 => 22,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 7,);
    }
}
