<?php

/* kd-hasil-data.html */
class __TwigTemplate_14d0a5b4e2c93f874adca7d7472609cce7ef89e257c890fa35f0b4c6b5661172 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Hasil Data - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("plugins/pencapaian_kd", "Analisis Pencapaian Kompetensi Dasar");
        echo " / Hasil Data</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("kd");
        echo "

        <table class=\"table table-bordered datatable table-striped\">
            <thead>
                <tr>
                    <th width=\"10%\">Analisis ID</th>
                    <th>Tugas & Kopetensi Dasar</th>
                    <th width=\"15%\">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <tr>
                <td>#";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id"), "html", null, true);
        echo "</td>
                <td>
                    ID : ";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "id"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "judul"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "mapel"), "nama"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["r"]) ? $context["r"] : null), "tugas"), "nama_kelas"), "html", null, true);
        echo "<br>
                    <hr style=\"margin-top:5px; margin-bottom: 5px;\">
                    KD : ";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "kd_mapel_nama"), "html", null, true);
        echo "
                    <br>Nilai Minimal Lulus : ";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "nilai_lulus"), "html", null, true);
        echo "
                </td>
                <td>
                    <div class=\"btn-group\">
                        <a class=\"btn btn-xs btn-default\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, site_url(((("plugins/pencapaian_kd/edit/" . $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id")) . "/") . enurl_redirect(current_url()))), "html", null, true);
        echo "\"><i class=\"icon icon-edit\"></i> Edit</a>
                        <a class=\"btn btn-xs btn-primary\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, site_url(("plugins/pencapaian_kd/kd_no_soal/" . $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id"))), "html", null, true);
        echo "\"><i class=\"icon icon-th\"></i> KD No.Soal</a>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
        <br>

        ";
        // line 43
        echo form_open("", array("class" => "form-horizontal row-fluid"));
        echo "
            <div class=\"control-group\">
                <label class=\"control-label\">Lihat data</label>
                <div class=\"controls\">
                    <select name=\"tipe\" id=\"tipe\">
                        <option value=\"analisis_kd\">ANALISIS KD</option>
                        ";
        // line 49
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kelas_nilai"]) ? $context["kelas_nilai"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 50
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "                    </select>
                </div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\">
                    <button type=\"button\" class=\"btn btn-primary\" id=\"btn-lihat\">Lihat</button>
                </div>
            </div>
        ";
        // line 60
        echo form_close();
        echo "

    </div>
</div>
";
    }

    // line 66
    public function block_js($context, array $blocks = array())
    {
        // line 67
        echo "<script type=\"text/javascript\">
    \$(document).on('click', '#btn-lihat', function() {
        var tipe = \$(\"#tipe\").val();
        window.open(site_url + '/plugins/pencapaian_kd/hasil_data/";
        // line 70
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : null), "id"), "html", null, true);
        echo "/' + tipe, '_blank');
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "kd-hasil-data.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 70,  156 => 67,  153 => 66,  144 => 60,  134 => 52,  123 => 50,  119 => 49,  110 => 43,  99 => 35,  95 => 34,  88 => 30,  84 => 29,  73 => 27,  68 => 25,  53 => 13,  47 => 10,  43 => 8,  40 => 7,  33 => 4,  30 => 3,);
    }
}
