<?php

/* kd-list-tugas.html */
class __TwigTemplate_d65ef097aa51c23b7245e1f903147423c9b015f2b102213de3ff2649eb52b116 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Analisis Pencapaian Kompetensi Dasar -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>Analisis Pencapaian Kompetensi Dasar</h3>
    </div>
    <div class=\"module-body\">";
        // line 13
        echo get_flashdata("kd");
        echo "

        <div class=\"btn-group\">
            <a class=\"btn btn-primary\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, site_url("plugins/pencapaian_kd/add"), "html", null, true);
        echo "\">Tambah Analisis</a>
        </div>
        <br>
        <br>

        <table class=\"table table-bordered datatable table-striped\">
            <thead>
                <tr>
                    <th width=\"10%\">Analisis ID</th>
                    <th>Tugas & Kopetensi Dasar</th>
                    <th width=\"15%\">Aksi</th>
                </tr>
            </thead>
            <tbody>";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tugas"]) ? $context["tugas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 31
            echo "            <tr>
                <td>#";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"), "html", null, true);
            echo "</td>
                <td>
                    ID :";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "tugas"), "id"), "html", null, true);
            echo " -";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "tugas"), "judul"), "html", null, true);
            echo " -";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "tugas"), "mapel"), "nama"), "html", null, true);
            echo " -";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["t"]) ? $context["t"] : null), "tugas"), "nama_kelas"), "html", null, true);
            echo "<br>
                    <hr style=\"margin-top:5px; margin-bottom: 5px;\">
                    KD :";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "kd_mapel_nama"), "html", null, true);
            echo "
                    <br>Nilai Minimal Lulus :";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "nilai_lulus"), "html", null, true);
            echo "
                </td>
                <td>
                    <div class=\"btn-group\">
                        <a class=\"btn btn-xs btn-default\" href=\"";
            // line 41
            echo twig_escape_filter($this->env, site_url(((("plugins/pencapaian_kd/edit/" . $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id")) . "/") . enurl_redirect(current_url()))), "html", null, true);
            echo "\"><i class=\"icon icon-edit\"></i> Edit</a>
                        <a class=\"btn btn-xs btn-primary\" href=\"";
            // line 42
            echo twig_escape_filter($this->env, site_url(("plugins/pencapaian_kd/kd_no_soal/" . $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"icon icon-th\"></i> KD No.Soal</a>
                        <a class=\"btn btn-xs btn-success\" href=\"";
            // line 43
            echo twig_escape_filter($this->env, site_url(("plugins/pencapaian_kd/hasil_data/" . $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"icon icon-download\"></i> Hasil Data</a>
                        <a class=\"btn btn-xs btn-danger\" href=\"";
            // line 44
            echo twig_escape_filter($this->env, site_url(("plugins/pencapaian_kd/delete/" . $this->getAttribute((isset($context["t"]) ? $context["t"] : null), "id"))), "html", null, true);
            echo "\" onclick=\"return confirm('Anda yakin ingin menghapus?')\"><i class=\"icon icon-trash\"></i> Hapus</a>
                    </div>
                </td>
            </tr>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "            </tbody>
        </table>

    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "kd-list-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 49,  114 => 44,  110 => 43,  106 => 42,  102 => 41,  95 => 37,  91 => 36,  80 => 34,  75 => 32,  72 => 31,  68 => 30,  52 => 16,  46 => 13,  40 => 8,  37 => 7,  32 => 4,  29 => 3,);
    }
}
