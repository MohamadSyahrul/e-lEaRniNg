<?php

/* tk-edit-kelompok.html */
class __TwigTemplate_9eeb7c27a0a3935e101d46ed38201f31f6dd46903469ce599c809b7734f62779 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Tambah Kelompok -";
        $this->displayParentBlock("title", $context, $blocks);
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("plugins/tugas_kelompok", "Tugas Kelompok");
        echo " /";
        echo anchor(("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")), "List Kelompok");
        echo " / Edit Kelompok</h3>
    </div>
    <div class=\"module-body\">";
        // line 13
        echo get_flashdata("tugas");
        // line 15
        echo form_open_multipart(((("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")) . "/edit/") . $this->getAttribute((isset($context["kelompok"]) ? $context["kelompok"] : null), "id")), array("class" => "form-horizontal row-fluid"));
        echo "
            <div class=\"control-group\">
                <label class=\"control-label\">Nama <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"nama\" class=\"span7\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, set_value("nama", $this->getAttribute((isset($context["kelompok"]) ? $context["kelompok"] : null), "nama")), "html", null, true);
        echo "\">
                    <br>";
        // line 20
        echo form_error("nama");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Intruksi / Informasi</label>
                <div class=\"controls\">
                    <textarea name=\"intruksi\" class=\"texteditor\">";
        // line 26
        echo set_value("intruksi", $this->getAttribute((isset($context["kelompok"]) ? $context["kelompok"] : null), "intruksi"));
        echo "</textarea>
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Anggota <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <input type=\"text\" id=\"cari-siswa\" class=\"span6\" placeholder=\"Cari siswa";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "kelas"), "nama"), "html", null, true);
        echo "\">
                    <br><br>
                    <table class=\"table table-bordered table-striped table-condensed\" id=\"table-anggota\">
                        <thead>
                            <tr>
                                <th width=\"15%\">Nis</th>
                                <th>Nama</th>
                                <th width=\"20%\">Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <br>";
        // line 44
        echo form_error("anggota");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\">
                    <button type=\"submit\" class=\"btn btn-primary\">Update</button>
                    <a href=\"";
        // line 50
        echo twig_escape_filter($this->env, site_url(("plugins/tugas_kelompok/kelompok/" . $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id"))), "html", null, true);
        echo "\" class=\"btn btn-default\">Kembali</a>
                </div>
            </div>";
        // line 53
        echo form_close();
        echo "
    </div>
</div>";
    }

    // line 58
    public function block_js($context, array $blocks = array())
    {
        // line 59
        echo "<script type=\"text/javascript\">
    var kelompok_id = \"";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["kelompok"]) ? $context["kelompok"] : null), "id"), "html", null, true);
        echo "\";
    var tugas_id = \"";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id"), "html", null, true);
        echo "\";

    \$('#cari-siswa').autocomplete({
        serviceUrl: site_url + '/plugins/tugas_kelompok/ajax/cari-siswa?kelas_id=";
        // line 64
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "kelas"), "id"), "html", null, true);
        echo "',
        onSelect: function (suggestion) {
            add_to_session(suggestion.id);
            \$(this).val(\"\");
        }
    });

    function add_to_session(siswa_id) {
        \$.ajax({
            type: \"POST\",
            url: site_url + '/plugins/tugas_kelompok/ajax/add-to-sess-edit',
            data: {'siswa_id' : siswa_id, 'kelompok_id' : kelompok_id, 'tugas_id' : tugas_id},
            success: function (data) {
                if (data == \"0\") {
                    alert(\"Siswa sudah ada pada kelompok lain.\");
                } else {
                    show_sess_anggota(0);
                }
            }
        });
    }

    function show_sess_anggota(pertama)
    {
        \$(\"#table-anggota tbody\").empty();
        \$.ajax({
            type: \"GET\",
            url: site_url + '/plugins/tugas_kelompok/ajax/get-edit-sess',
            data: {'kelompok_id' : kelompok_id, 'pertama' : pertama},
            success: function (data) {
                var hasil = \$.parseJSON(data);
                \$.each(hasil, function (i, val) {
                    \$(\"#table-anggota tbody\").append(\"<tr><td>\" + val.nis + \"</td><td>\" + val.nama + \"</td><td><a href='javascript:void(0)' class='delete-sess-anggota' data-id='\" + val.id + \"'>Hapus</a></td></tr>\");
                })
            }
        });
    }

    show_sess_anggota(1);

    \$(document).on('click', '.delete-sess-anggota', function() {
        var conf = confirm('Anda yakin ingin menghapus?');
        if (conf) {
            \$.ajax({
                type: \"POST\",
                url: site_url + '/plugins/tugas_kelompok/ajax/delete-edit-sess',
                data: {'kelompok_id' : kelompok_id, 'siswa_id' : \$(this).data('id')},
                success: function() {
                    show_sess_anggota(0);
                }
            });
        }
    });
</script>";
    }

    public function getTemplateName()
    {
        return "tk-edit-kelompok.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 64,  129 => 61,  125 => 60,  122 => 59,  119 => 58,  112 => 53,  107 => 50,  98 => 44,  83 => 32,  74 => 26,  65 => 20,  61 => 19,  54 => 15,  52 => 13,  45 => 10,  41 => 8,  38 => 7,  33 => 4,  30 => 3,);
    }
}
